<!DOCTYPE html>
<html>

<head>
    <title>Email</title>
</head>

<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
</body>

</html>
