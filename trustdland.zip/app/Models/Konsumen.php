<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Konsumen extends Model
{
    use HasFactory;

    public function user()
    {
        return $this->belongsTo(User::class, 'id_user');
    }

    public function bangunan()
    {
        return $this->hasMany(Bangunan::class, 'id_konsumen'); // Relasi hasMany
    }
}
