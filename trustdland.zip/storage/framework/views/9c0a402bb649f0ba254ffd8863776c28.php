<nav class="navbar navbar-expand-lg navbar-light ftco_navbar bg-light ftco-navbar-dark" id="ftco-navbar">
    <div class="container">
        <a class="navbar-brand" href="/"><img src="<?php echo e(asset('images/icon-moobil-erase.png')); ?>" style="width: 60px;"
                alt="">
            Rent <span>Moobil</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
            aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item "><a href="/"
                        class="nav-link mr-2 <?php echo e(Request::is('/') ? 'text-primary' : 'text-dark'); ?>">Beranda</a>
                </li>
                <li class="nav-item"><a href="/mobil"
                        class="nav-link mr-2 <?php echo e(Request::is('mobil') ? 'text-primary' : 'text-dark'); ?>">Mobil</a>
                </li>
                <li class="nav-item"><a href="/tentang-kami"
                        class="nav-link mr-2 <?php echo e(Request::is('tentang-kami') ? 'text-primary' : 'text-dark'); ?>">Tentang
                        Kami</a></li>
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item"><a href="/register" class="btn btn-outline-primary ml-3 mt-1 mr-3">Register</a>
                    </li>
                    <li class="nav-item"><a href="/login" class="btn btn-primary mt-1">Login</a></li>
                <?php else: ?>
                    <li class="nav-item"><a href="/member/profil"
                            class="nav-link mr-2 <?php echo e(Request::is('member/profil') ? 'text-primary' : 'text-dark'); ?>"><?php echo e(Auth::user()->name); ?>

                            <i class="fa fa-user ml-2"></i></a></li>
                    <li class="nav-item"><a href="" class="btn btn-outline-primary ml-2 mt-1"
                            href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">Logout</a>
                    </li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rental_mobil/resources/views/layouts/partials/member/header.blade.php ENDPATH**/ ?>