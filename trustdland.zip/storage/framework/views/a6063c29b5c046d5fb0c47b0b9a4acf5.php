<!DOCTYPE html>
<html>

<head>
    <title>Email</title>
</head>

<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rental_mobil/resources/views/member/konfirmasi-pembayaran.blade.php ENDPATH**/ ?>