<footer class="footer text-center">
    Admin Trustdland
</footer>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/trustdland/resources/views/layouts/partials/admin/footer.blade.php ENDPATH**/ ?>