<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card mt-4">
                    <div class="card-header">Tambah Bangunan</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('bangunan.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="nama_project" class="col-md-4 col-form-label text-md-right">Pilih
                                    Konsumen</label>

                                <div class="col-md-6">
                                    <select name="id_konsumen"
                                        class="form-select <?php $__errorArgs = ['id_konsumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Pilih Konsumen</option>
                                        <?php $__currentLoopData = $konsumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['id_konsumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="id_project" class="col-md-4 col-form-label text-md-right">Pilih Project</label>

                                <div class="col-md-6">
                                    <select name="id_project" id="id_project" class="form-select">
                                        <option value="">Pilih Project</option>
                                        <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_project); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['id_project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="lat" class="col-md-4 col-form-label text-md-right">Pilih Siteplan</label>

                                <div class="col-md-6">
                                    <select name="id_siteplan" id="id_siteplan" class="form-select">
                                        <option value="">Pilih Siteplan</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="long" class="col-md-4 col-form-label text-md-right">Tanggal
                                    Pembelian</label>

                                <div class="col-md-6">
                                    <input id="tgl_pembelian" type="date"
                                        class="form-control <?php $__errorArgs = ['tgl_pembelian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tgl_pembelian" value="<?php echo e(old('tgl_pembelian')); ?>" autocomplete="tgl_pembelian"
                                        autofocus>

                                    <?php $__errorArgs = ['tgl_pembelian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Simpan
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="height: 300px;"></div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('#id_project').on('change', function() {
            const projectId = $(this).val();
            const taskSelect = $('#id_siteplan');
            const taskError = $('#task-error');

            taskSelect.html('<option value="">Pilih Siteplan</option>'); // Reset options
            taskError.hide(); // Hide error

            if (projectId) {
                $.ajax({
                    url: `/admin/pilih-siteplan/${projectId}`,
                    type: 'GET',
                    success: function(tasks) {
                        tasks.forEach(task => {
                            taskSelect.append(
                                `<option value="${task.id}">${task.kode} - ${task.luas}</option>`
                            );
                        });
                    },
                    error: function() {
                        taskError.show();
                        taskError.find('strong').text('Gagal mengambil data task.');
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/trustdland/resources/views/admin/bangunan/create.blade.php ENDPATH**/ ?>