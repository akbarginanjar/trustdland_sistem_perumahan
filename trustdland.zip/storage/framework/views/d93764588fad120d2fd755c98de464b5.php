 

 <?php $__env->startSection('content'); ?>
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.11.4/datatables.min.css" />
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
     <script src="https://cdn.datatables.net/v/bs4/dt-1.11.4/datatables.min.js"></script>
     <script type="text/javascript">
         jQuery(document).ready(function($) {
             $('#siteplan').DataTable();
         });
     </script>
     <div class="page-breadcrumb">
         <div class="row align-items-center">
             <div class="col-6">
                 <nav aria-label="breadcrumb">
                     <ol class="breadcrumb mb-0 d-flex align-items-center">
                         <li class="breadcrumb-item"><a href="" class="link"><i
                                     class="mdi mdi-home-outline fs-4"></i></a></li>
                         <li class="breadcrumb-item active" aria-current="page">Siteplan</li>
                     </ol>
                 </nav>
                 <h1 class="mb-0 fw-bold">Siteplan</h1>
             </div>
             <div class="col-6">
                 <div class="text-end upgrade-btn">
                     <a href="/admin/project/<?php echo e($project->id); ?>/siteplan/create" class="btn btn-primary text-white">Tambah
                         Baru</a>
                 </div>
             </div>
         </div>
     </div>

     <div class="container-fluid">
         <?php if(session('success')): ?>
             <div class="alert alert-success alert-dismissible fade show" role="alert">
                 <?php echo e(session('success')); ?>

                 <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
             </div>
         <?php endif; ?>
         <div class="card">
             <div class="card-body">
                 <div class="table-responsive">
                     <table class="table" id="siteplan">
                         <thead>
                             <tr>
                                 <th scope="col" class="px-6 py-3">No</th>
                                 <th scope="col" class="px-6 py-3">Kode</th>
                                 <th scope="col" class="px-6 py-3">Luas</th>
                                 <th scope="col" class="px-6 py-3">Aksi</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php
                                 $no = 1;
                             ?>
                             <?php $__currentLoopData = $siteplan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr class="">
                                     <td class="px-6 py-4"><?php echo e($no++); ?></td>
                                     <td class="px-6 py-4"><?php echo e($item->kode); ?></td>
                                     <td class="px-6 py-4"><?php echo e($item->luas); ?></td>
                                     <td class="">
                                         <form class=""
                                             action="/admin/project/<?php echo e($project->id); ?>/siteplan/<?php echo e($item->id); ?>/delete"
                                             method="post">
                                             <?php echo method_field('delete'); ?>
                                             <?php echo csrf_field(); ?>
                                             <a href="/admin/project/<?php echo e($project->id); ?>/siteplan/<?php echo e($item->id); ?>/edit"
                                                 class="btn btn-warning text-white btn-sm">Edit</a>
                                             <button type="submit" class="btn btn-outline-danger btn-sm"
                                                 onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Delete</button>

                                         </form>
                                     </td>
                                 </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/trustdland/resources/views/admin/siteplan/index.blade.php ENDPATH**/ ?>