<?php if(Auth::user()->role_id == 1): ?>
    <script>
        window.location = "/admin/dashboard";
    </script>
<?php elseif(Auth::user()->role_id == 2): ?>
    <script>
        window.location = "/";
    </script>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rental_mobil/resources/views/home.blade.php ENDPATH**/ ?>