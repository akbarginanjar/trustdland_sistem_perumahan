<footer class="footer text-center">
    Aplikasi Rental Mobil 2024
</footer>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rental_mobil/resources/views/layouts/partials/admin/footer.blade.php ENDPATH**/ ?>