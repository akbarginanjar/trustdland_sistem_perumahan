<aside class="left-sidebar" data-sidebarbg="skin6">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="sidebar-item"> <a
                        class="sidebar-link waves-effect waves-dark sidebar-link <?php echo e(Request::is('admin/dashboard') ? 'bg-primary' : ''); ?>"
                        href="/admin/dashboard" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span
                            class="hide-menu">Dashboard</span></a></li>
                <li class="sidebar-item"> <a
                        class="sidebar-link waves-effect waves-dark sidebar-link <?php echo e(Request::is('admin/mobil') ? 'bg-primary' : ''); ?>"
                        href="/admin/mobil" aria-expanded="false"><i class="fa-solid fa-car me-2"></i><span
                            class="hide-menu">Mobil</span></a></li>
                <li class="sidebar-item"> <a
                        class="sidebar-link waves-effect waves-dark sidebar-link <?php echo e(Request::is('admin/transaksi') ? 'bg-primary' : ''); ?>"
                        href="/admin/transaksi" aria-expanded="false"><i class="fa-solid fa-receipt me-2"></i><span
                            class="hide-menu">Transaksi</span></a></li>
                <li class="sidebar-item"> <a
                        class="sidebar-link waves-effect waves-dark sidebar-link <?php echo e(Request::is('admin/penyewa') ? 'bg-primary' : ''); ?>"
                        href="/admin/penyewa" aria-expanded="false"><i class="fa-solid fa-address-card me-2"></i><span
                            class="hide-menu">Penyewa</span></a></li>
                <li class="sidebar-item"> <a
                        class="sidebar-link waves-effect waves-dark sidebar-link <?php echo e(Request::is('admin/user') ? 'bg-primary' : ''); ?>"
                        href="/admin/user" aria-expanded="false"><i class="fa-solid fa-user me-2"></i><span
                            class="hide-menu">Users</span></a></li>
                
            </ul>

        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rental_mobil/resources/views/layouts/partials/admin/sidebar.blade.php ENDPATH**/ ?>