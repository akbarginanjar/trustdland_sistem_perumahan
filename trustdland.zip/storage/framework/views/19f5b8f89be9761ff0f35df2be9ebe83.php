<?php $__env->startSection('content'); ?>
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 d-flex align-items-center">
                        <li class="breadcrumb-item"><a href="index.html" class="link"><i
                                    class="mdi mdi-home-outline fs-4"></i></a></li>
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
                <h1 class="mb-0 fw-bold">Dashboard</h1>
            </div>
            <div class="col-6">
                
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <div class="d-md-flex align-items-center">
                            <div>
                                <h4 class="card-title">Grafik Sewa</h4>
                                <h6 class="card-subtitle">Grafik Penyewaan Perbulan</h6>
                            </div>
                            <div class="ms-auto d-flex no-block align-items-center">
                            </div>
                        </div>
                        <div class="pixel-Ample mt-4" style="height: 350px;">
                            <div class="chartist-tooltip"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Transaksi Terbaru</h4>
                        <h6 class="card-subtitle mb-4">Segera konfirmasi</h6>

                        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->status == '1'): ?>
                                <div class="mt-2 pb-3 d-flex align-items-center">
                                    <span class="btn btn-success text-white btn-circle d-flex align-items-center">
                                        <i class="fa fa-car fs-4"></i>
                                    </span>
                                    <div class="ms-3">
                                        <h5 class="mb-0 fw-bold"><?php echo e($item->penyewa->user->name); ?></h5>
                                        <span class="text-muted fs-6"><?php echo e($item->mobil->merk); ?></span>
                                    </div>
                                    <div class="ms-auto">
                                        <span class="badge bg-light text-muted">Pending</span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script
        src="https://www.wrappixel.com/demos/free-admin-templates/all-lite-landing-pages/assets/plugins/jquery/dist/jquery.min.js">
    </script>
    <!-- Bootstrap tether Core JavaScript -->
    <script>
        $(function() {
            "use strict";
            var chart2 = new Chartist.Bar(
                ".pixel-Ample", {
                    labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus",
                        "September", "Oktober", "November", "Desember"
                    ],
                    series: [{
                        name: 'series-1',
                        data: [<?php echo e($januari); ?>, <?php echo e($februari); ?>, <?php echo e($maret); ?>,
                            <?php echo e($april); ?>, <?php echo e($mei); ?>,
                            <?php echo e($juni); ?>, <?php echo e($juli); ?>, <?php echo e($agustus); ?>,
                            <?php echo e($september); ?>,
                            <?php echo e($oktober); ?>, <?php echo e($november); ?>, <?php echo e($desember); ?>

                        ]
                    }],
                }, {
                    axisX: {
                        position: "end",
                        showGrid: false,
                    },
                    axisY: {
                        position: "start",
                    },
                    high: 100,
                    low: 0,
                    plugins: [Chartist.plugins.tooltip()],
                }
            );

            var chart = [chart2];
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rental_mobil/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>