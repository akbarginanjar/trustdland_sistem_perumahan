 

 <?php $__env->startSection('content'); ?>
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.11.4/datatables.min.css" />
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
     <script src="https://cdn.datatables.net/v/bs4/dt-1.11.4/datatables.min.js"></script>
     <script type="text/javascript">
         jQuery(document).ready(function($) {
             $('#konsumen').DataTable();
         });
     </script>
     <div class="page-breadcrumb">
         <div class="row align-items-center">
             <div class="col-6">
                 <nav aria-label="breadcrumb">
                     <ol class="breadcrumb mb-0 d-flex align-items-center">
                         <li class="breadcrumb-item"><a href="" class="link"><i
                                     class="mdi mdi-home-outline fs-4"></i></a></li>
                         <li class="breadcrumb-item active" aria-current="page">Konsumen</li>
                     </ol>
                 </nav>
                 <h1 class="mb-0 fw-bold">Konsumen</h1>
             </div>
             <div class="col-6">
                 <div class="text-end upgrade-btn">
                     <a href="<?php echo e(route('konsumen.create')); ?>" class="btn btn-primary text-white">Tambah Baru</a>
                 </div>
             </div>
         </div>
     </div>

     <div class="container-fluid">
         <?php if(session('success')): ?>
             <div class="alert alert-success alert-dismissible fade show" role="alert">
                 <?php echo e(session('success')); ?>

                 <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
             </div>
         <?php endif; ?>
         <div class="card">
             <div class="card-body">
                 <div class="table-responsive">
                     <table class="table" id="konsumen">
                         <thead>
                             <tr>
                                 <th scope="col" class="px-6 py-3">No</th>
                                 <th scope="col" class="px-6 py-3">Name</th>
                                 <th scope="col" class="px-6 py-3">No Telepon/Whatsapp</th>
                                 <th scope="col" class="px-6 py-3">Alamat</th>
                                 <th scope="col" class="px-6 py-3">Email</th>
                                 <th scope="col" class="px-6 py-3">Aksi</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php
                                 $no = 1;
                             ?>
                             <?php $__currentLoopData = $konsumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr class="">
                                     <td class="px-6 py-4"><?php echo e($no++); ?></td>
                                     <td class="px-6 py-4"><?php echo e($item->user->name); ?></td>
                                     <td class="px-6 py-4"><?php echo e($item->no_telepon); ?></td>
                                     <td class="px-6 py-4"><?php echo e($item->alamat); ?></td>
                                     <td class="px-6 py-4"> <?php echo e($item->user->email); ?> </td>
                                     <td class="">
                                         <form class="" action="<?php echo e(route('konsumen.destroy', $item->id)); ?>"
                                             method="post">
                                             <?php echo method_field('delete'); ?>
                                             <?php echo csrf_field(); ?>
                                             <a href="<?php echo e(route('konsumen.edit', $item->id)); ?>"
                                                 class="btn btn-warning text-white btn-sm">Edit</a>
                                             <button type="submit" class="btn btn-outline-danger btn-sm"
                                                 onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Delete</button>

                                         </form>
                                     </td>
                                 </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/trustdland/resources/views/admin/konsumen/index.blade.php ENDPATH**/ ?>