<?php if(Auth::user()->role_id == 1): ?>
    <script>
        window.location = "/admin/dashboard";
    </script>
<?php elseif(Auth::user()->role_id == 2): ?>
    <script>
        window.location = "/member/dashboard";
    </script>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/trustdland/resources/views/home.blade.php ENDPATH**/ ?>