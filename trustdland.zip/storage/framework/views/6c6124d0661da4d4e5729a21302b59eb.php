<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.11.4/datatables.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/v/bs4/dt-1.11.4/datatables.min.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#mobil').DataTable();
        });
    </script>
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 d-flex align-items-center">
                        <li class="breadcrumb-item"><a href="index.html" class="link"><i
                                    class="mdi mdi-home-outline fs-4"></i></a></li>
                        <li class="breadcrumb-item active" aria-current="page">Mobil</li>
                    </ol>
                </nav>
                <h1 class="mb-0 fw-bold">Mobil</h1>
            </div>
            <div class="col-6">
                <div class="text-end upgrade-btn">
                    <a href="<?php echo e(route('mobil.create')); ?>" class="btn btn-primary text-white">Tambah Baru</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="mobil">
                        <thead>
                            <tr>
                                <th scope="col" class="px-6 py-3">No</th>
                                <th scope="col" class="px-6 py-3">Foto</th>
                                <th scope="col" class="px-6 py-3">Plat</th>
                                <th scope="col" class="px-6 py-3">Nomer mobil</th>
                                <th scope="col" class="px-6 py-3">merk</th>
                                <th scope="col" class="px-6 py-3">Jenis</th>
                                <th scope="col" class="px-6 py-3">Harga sewa</th>
                                <th scope="col" class="px-6 py-3">Status</th>
                                <th scope="col" class="px-6 py-3">Aksi</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $mobil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b ">
                                    <td class="px-6 py-4"><?php echo e($no++); ?></td>
                                    <td class="px-6 py-4"><img src="<?php echo e($item->gambar()); ?>" width="100px;" alt="">
                                    </td>
                                    <td class="px-6 py-4"><?php echo e($item->plat); ?></td>
                                    <td class="px-6 py-4"> <?php echo e($item->nomor_mobil); ?> </td>
                                    <td class="px-6 py-4"> <?php echo e($item->merk); ?> </td>
                                    <td class="px-6 py-4"> <?php echo e($item->jenis); ?> </td>
                                    <td class="px-6 py-4"> <?php echo e($item->harga_sewa); ?> </td>
                                    <td class="px-6 py-4">
                                        <?php if($item->status == 'Tersedia'): ?>
                                            <div class="bg-success text-white p-1 rounded text-center" style="width: 80px;">
                                                Tersedia</div>
                                        <?php else: ?>
                                            <div class="bg-primary text-white p-1 rounded text-center" style="width: 80px;">
                                                Sedang Disewa</div>
                                        <?php endif; ?>
                                    </td>
                                    <td style="width: 200px;">
                                        <form class="" action="<?php echo e(route('mobil.destroy', $item->id)); ?>"
                                            method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <a href="<?php echo e(route('mobil.edit', $item->id)); ?>"
                                                class="btn btn-warning text-white btn-sm <?php echo e($item->status != 'Tersedia' ? 'disabled' : ''); ?>">Edit</a>
                                            <button type="submit"
                                                class="btn btn-outline-danger btn-sm <?php echo e($item->status != 'Tersedia' ? 'disabled' : ''); ?>"
                                                onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rental_mobil/resources/views/admin/mobil/index.blade.php ENDPATH**/ ?>