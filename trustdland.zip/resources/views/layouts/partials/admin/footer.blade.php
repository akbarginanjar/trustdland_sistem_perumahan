<footer class="footer text-center">
    Admin Trustdland
</footer>
